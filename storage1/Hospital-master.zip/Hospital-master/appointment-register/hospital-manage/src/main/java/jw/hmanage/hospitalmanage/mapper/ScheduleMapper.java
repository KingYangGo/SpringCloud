package jw.hmanage.hospitalmanage.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import jw.hmanage.hospitalmanage.model.Schedule;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface ScheduleMapper extends BaseMapper<Schedule> {

}
