package jw.hospital.cmn.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import jw.hospital.model.cmn.Dict;

public interface DictMapper extends BaseMapper<Dict> {

}
