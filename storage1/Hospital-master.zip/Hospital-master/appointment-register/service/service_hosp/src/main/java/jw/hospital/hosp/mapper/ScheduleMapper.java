package jw.hospital.hosp.mapper;

import jw.hospital.model.hosp.Schedule;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

public interface ScheduleMapper extends BaseMapper<Schedule> {
}
