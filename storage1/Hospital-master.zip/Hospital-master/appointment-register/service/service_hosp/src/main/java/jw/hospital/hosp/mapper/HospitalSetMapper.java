package jw.hospital.hosp.mapper;

import jw.hospital.model.hosp.HospitalSet;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

public interface HospitalSetMapper extends BaseMapper<HospitalSet> {

}
